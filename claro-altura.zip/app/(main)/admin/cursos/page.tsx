import { db } from "@/lib/db";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CoursesDataTable } from "./_components/courses-datatable";
import { coursesDataTableColumns } from "./_components/courses-datatable-column";

const InspectionsPage = async () => {
  const reports = await db.report.findMany({
    orderBy: {
      createdAt: "desc",
    },
  });
  return (
    <Card className="max-w-[1500px] h-fit mx-auto p-1 rounded-sm">
      <CardHeader className="flex justify-between gap-y-1">
        <div className="flex flex-col">
          <h1 className="text-2xl font-semibold">
            Listado de cursos
          </h1>
          <span className="text-sm text-slate-500 font-light">
            Listado completo de todos los cursos registrados
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <CoursesDataTable columns={coursesDataTableColumns} data={reports} />
      </CardContent>
    </Card>
  );
};

export default InspectionsPage;
