import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/utils";
import { ColumnDef } from "@tanstack/react-table";
import { ArrowUpDown } from "lucide-react";

export const coursesDataTableColumns: ColumnDef<any>[] = [
  {
    accessorKey: "deliveryDate",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        >
          Fecha de entrega
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },

    accessorFn: (value) => formatDate(new Date(value.deliveryDate)),
  },
];
